// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportApiCurrentUser = require('../../../app/controller/api/currentUser');
import ExportApiFile = require('../../../app/controller/api/file');
import ExportApiFolder = require('../../../app/controller/api/folder');
import ExportApiLogin = require('../../../app/controller/api/login');
import ExportApiRegister = require('../../../app/controller/api/register');
import ExportApiSearch = require('../../../app/controller/api/search');
import ExportApiUserCenter = require('../../../app/controller/api/userCenter');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    api: {
      currentUser: ExportApiCurrentUser;
      file: ExportApiFile;
      folder: ExportApiFolder;
      login: ExportApiLogin;
      register: ExportApiRegister;
      search: ExportApiSearch;
      userCenter: ExportApiUserCenter;
    }
  }
}
